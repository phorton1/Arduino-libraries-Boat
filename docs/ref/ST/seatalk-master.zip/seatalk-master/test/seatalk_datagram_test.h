void test_seatalk_datagram();

