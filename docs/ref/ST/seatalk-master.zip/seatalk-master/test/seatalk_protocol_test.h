void test_seatalk_protocol();
