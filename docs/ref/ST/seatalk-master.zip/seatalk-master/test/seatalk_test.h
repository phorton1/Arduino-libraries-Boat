void simulate_character(char byte, int command_bit);
void simulate_datagram(char *datagram, int length);
