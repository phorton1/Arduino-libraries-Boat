#include "../timeout.h"

void test_boat_status();
