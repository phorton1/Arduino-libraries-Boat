int set_bytes_to_send(const char *buf, int count);
int get_received_bytes(char *buf);
