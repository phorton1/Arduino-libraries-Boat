void clear_all_commands();
void test_seatalk_command();
