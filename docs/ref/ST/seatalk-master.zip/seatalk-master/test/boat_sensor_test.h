void invalidate_all_sensors();
void test_boat_sensor();
