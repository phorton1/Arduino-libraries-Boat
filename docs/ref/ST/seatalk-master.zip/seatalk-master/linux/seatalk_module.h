void state_updated(void);
